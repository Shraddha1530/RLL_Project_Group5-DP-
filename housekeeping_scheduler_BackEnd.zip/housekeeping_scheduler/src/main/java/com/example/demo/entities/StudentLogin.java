package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "Student_SignIn")
public class StudentLogin {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "rollnumber")
		private long rollnumber;

		@Column(name = "password")
		private String password;

		public StudentLogin() {
			super();
			
		}

		public StudentLogin(long rollnumber, String password) {
			super();
			this.rollnumber = rollnumber;
			this.password = password;
		}

		public long getRollnumber() {
			return rollnumber;
		}

		public void setRollnumber(long rollnumber) {
			this.rollnumber = rollnumber;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		@Override
		public String toString() {
			return "StudentLogin [rollnumber=" + rollnumber + ", password=" + password + "]";
		}

        
}
