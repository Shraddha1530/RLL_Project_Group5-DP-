package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.StudentRegistration;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repositories.StudentRegistrationRepo;

@Service
public class StudentRegistrationImpl implements StudentRegistrationService{
	
	@Autowired
	private StudentRegistrationRepo studentRegistrationRepo;

	public StudentRegistrationImpl(StudentRegistrationRepo studentRegistrationRepo) {
		super();
		this.studentRegistrationRepo = studentRegistrationRepo;
	}

	@Override
	public StudentRegistration saveStudentRegistration(StudentRegistration studentRegistration) {
		return studentRegistrationRepo.save(studentRegistration);
	}

	@Override
	public List<StudentRegistration> getAllStudent() {
		return studentRegistrationRepo.findAll();
	}


	@Override
	public StudentRegistration getStudentRegistrationById(long id) {
		return studentRegistrationRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "Id", id));

	}
	
}
