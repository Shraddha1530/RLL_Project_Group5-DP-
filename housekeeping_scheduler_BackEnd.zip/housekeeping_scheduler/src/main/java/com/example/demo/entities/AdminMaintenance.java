package com.example.demo.entities;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "admin")
public class AdminMaintenance {
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "id")
		private long HK_id;

		@Column(name = "HK_name")
		private String HK_name;

		@Column(name = "HK_hostel")
		private String HK_hostel;

		@Column(name="HK_floor")
		private int HK_floor;
		
		@Column(name="HK_roomsCleaned")
		private int HK_roomsCleaned;
		
		@Column(name="HK_complaints")
		private int HK_complaints;

		public AdminMaintenance() {
			super();
			// TODO Auto-generated constructor stub
		}

		public AdminMaintenance(long hK_id, String hK_name, String hK_hostel, int hK_floor, int hK_roomsCleaned,
				int hK_complaints) {
			super();
			HK_id = hK_id;
			HK_name = hK_name;
			HK_hostel = hK_hostel;
			HK_floor = hK_floor;
			HK_roomsCleaned = hK_roomsCleaned;
			HK_complaints = hK_complaints;
		}

		public long getHK_id() {
			return HK_id;
		}

		public void setHK_id(long hK_id) {
			HK_id = hK_id;
		}

		public String getHK_name() {
			return HK_name;
		}

		public void setHK_name(String hK_name) {
			HK_name = hK_name;
		}

		public String getHK_hostel() {
			return HK_hostel;
		}

		public void setHK_hostel(String hK_hostel) {
			HK_hostel = hK_hostel;
		}

		public int getHK_floor() {
			return HK_floor;
		}

		public void setHK_floor(int hK_floor) {
			HK_floor = hK_floor;
		}

		public int getHK_roomsCleaned() {
			return HK_roomsCleaned;
		}

		public void setHK_roomsCleaned(int hK_roomsCleaned) {
			HK_roomsCleaned = hK_roomsCleaned;
		}

		public int getHK_complaints() {
			return HK_complaints;
		}

		public void setHK_complaints(int hK_complaints) {
			HK_complaints = hK_complaints;
		}

		@Override
		public String toString() {
			return "Admin [HK_id=" + HK_id + ", HK_name=" + HK_name + ", HK_hostel=" + HK_hostel + ", HK_floor="
					+ HK_floor + ", HK_roomsCleaned=" + HK_roomsCleaned + ", HK_complaints=" + HK_complaints + "]";
		}
		
		



}
