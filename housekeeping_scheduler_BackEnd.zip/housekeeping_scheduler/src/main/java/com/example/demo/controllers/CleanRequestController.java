package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.CleanRequest;
import com.example.demo.services.CleanRequestService;
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class CleanRequestController {
	
	@Autowired
	private CleanRequestService cleanRequestService;
	
	@GetMapping("cleanRequests")
	public List<CleanRequest> getAllRequests()
	{
		return cleanRequestService.getAll();
	}

}
