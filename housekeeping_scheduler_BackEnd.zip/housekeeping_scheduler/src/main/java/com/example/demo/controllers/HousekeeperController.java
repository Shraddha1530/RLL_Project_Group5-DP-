package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Housekeeper;
import com.example.demo.services.HousekeeperService;
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class HousekeeperController {
	
	@Autowired
	private HousekeeperService housekeeperService;

	public HousekeeperController(HousekeeperService housekeeperService) {
		super();
		this.housekeeperService = housekeeperService;
	}

	@PostMapping("/employees")
	public ResponseEntity<Housekeeper> saveEmployee(@RequestBody Housekeeper employee) {
		return new ResponseEntity<Housekeeper>(housekeeperService.saveEmployee(employee), HttpStatus.CREATED);
	}

	@GetMapping("/employees")
	public List<Housekeeper> getAllEmployees() {
		return housekeeperService.getAllEmployees();
	}

	@GetMapping("/employees/{id}")
	public ResponseEntity<Housekeeper> getEmployeeById(@PathVariable("id") long employeeId) {
		return new ResponseEntity<Housekeeper>(housekeeperService.getEmployeeById(employeeId), HttpStatus.OK);
	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@PutMapping(value="/employees/{id}",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Housekeeper> updateEmployee(@PathVariable("id") long id, @RequestBody Housekeeper employee) {
		return new ResponseEntity<Housekeeper>(housekeeperService.updateEmployee(employee, id), HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") long id) {

		housekeeperService.deleteEmployee(id);

		return new ResponseEntity<String>("Employee deleted successfully!.", HttpStatus.OK);
	}
	

}
