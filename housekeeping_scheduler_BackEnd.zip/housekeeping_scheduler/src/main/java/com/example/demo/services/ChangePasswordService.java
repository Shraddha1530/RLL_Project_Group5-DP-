package com.example.demo.services;

import com.example.demo.entities.ChangePassword;

public interface ChangePasswordService {

	ChangePassword changePassword(ChangePassword changePassword, long id);

}