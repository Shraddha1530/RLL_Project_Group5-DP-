package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.UserAuthentication;
import com.example.demo.services.UserAuthService;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class UserAuthController {
	
	
	@Autowired
	private UserAuthService userAuthService;
	
	
	@PostMapping("/register")
	public UserAuthentication Register(@RequestBody UserAuthentication user) {
		return userAuthService.register(user);

	}
	
	@PostMapping("/login")
	public UserAuthentication login(@RequestBody UserAuthentication user) {
		return userAuthService.login(user);

	}
	
}

