package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Housekeeper")
public class Housekeeper {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long worker_id;
	private String name;
	private String hostelName;
	private int floor;
	private int complaints;
	public Housekeeper() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Housekeeper(long worker_id, String name, String hostelName, int floor, int complaints) {
		super();
		this.worker_id = worker_id;
		this.name = name;
		this.hostelName = hostelName;
		this.floor = floor;
		this.complaints = complaints;
	}
	public long getWorker_id() {
		return worker_id;
	}
	public void setWorker_id(long worker_id) {
		this.worker_id = worker_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHostelName() {
		return hostelName;
	}
	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public int getComplaints() {
		return complaints;
	}
	public void setComplaints(int complaints) {
		this.complaints = complaints;
	}
	@Override
	public String toString() {
		return "Housekeeper [worker_id=" + worker_id + ", name=" + name + ", hostelName=" + hostelName + ", floor="
				+ floor + ", complaints=" + complaints + "]";
	}

	
	
	
	

}
